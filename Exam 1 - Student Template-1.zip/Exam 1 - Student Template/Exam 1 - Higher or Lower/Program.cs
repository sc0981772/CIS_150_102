﻿namespace LargestNumberFinder
{
    public class NumberProgram
    {
        static void Main(string[] args)
        {
            
        }

        public static int ProcessInput(string input, ref int largest)
        {

        }
    }
}
